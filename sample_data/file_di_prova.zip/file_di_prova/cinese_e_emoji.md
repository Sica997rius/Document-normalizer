# Appunti

Riunione con il cliente 你好 andata bene 👍
